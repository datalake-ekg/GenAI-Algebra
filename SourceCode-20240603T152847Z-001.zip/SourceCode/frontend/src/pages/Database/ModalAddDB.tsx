import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import Button from "antd/lib/button";
import Modal from "antd/lib/modal/Modal";
import Form from "antd/lib/form";
import AntInput from "antd/lib/input";
import { Select } from "antd";
import service from "../../partials/services/axios.config";
import { toast } from "react-toastify";
import GamePlatformIcon from "../../partials/common/GamePlatformIcon";
import { Upload } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import DynamicUpload from "../../partials/common/Forms/DynamicUpload";
function ModalAddDB(props) {
  const [form] = Form.useForm();
  const { isOpen, onClose, setIsLoading, setListDB } = props;
  const [listFiles, setListFiles] = useState<any>({});
  const onCloseModal = () => {
    onClose();
    setTimeout(() => {
      form.resetFields();
    }, 300);
  };

  const onAddDB = (values) => {
    let { DBName, file } = values;
    const formData = new FormData();
    formData.append("name", DBName);
    formData.append("file", listFiles["file"][0] as Blob);
    setIsLoading(true);
    service.post("/upload", formData).then(
      (res: any) => {
        toast(res.message || "Import database success!", {
          type: "success",
        });
        setIsLoading(false);
        onCloseModal();
      },
      () => setIsLoading(false)
    );
    window.location.reload();
  };

  const onSetListFiles = (fieldName, files) => {
    const newListFiles = { ...listFiles };
    newListFiles[fieldName] = files;
    setListFiles(newListFiles);
    form.setFields([{ name: fieldName, errors: [] }]);
  };

  return (
    <Form
      id="FormAddNewDB"
      labelAlign="left"
      form={form}
      labelCol={{ span: 24 }}
      wrapperCol={{ span: 24 }}
      onFinish={onAddDB}
    >
      <Modal
        title="Add new database"
        open={isOpen}
        onCancel={onCloseModal}
        footer={[
          <Button key="back" htmlType="button" onClick={onCloseModal}>
            Cancel
          </Button>,
          <Button
            key="submit"
            type="primary"
            htmlType="submit"
            form="FormAddNewDB"
          >
            Save
          </Button>,
        ]}
      >
        <Form.Item
          name="DBName"
          label="Database name"
          rules={[{ required: true, message: "Please enter database name" }]}
        >
          <AntInput allowClear placeholder="Enter a name" className="w-full" />
        </Form.Item>
        <Form.Item name="file" label="Bundle">
          <DynamicUpload
            wrapperClass=""
            isShowLabel={false}
            field="file"
            onSetListFiles={onSetListFiles}
            listFiles={listFiles["file"] || []}
            accept=".csv"
          />
        </Form.Item>
      </Modal>
    </Form>
  );
}

ModalAddDB.propTypes = {
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
  setIsLoading: PropTypes.func,
  setListDB: PropTypes.func,
};

export default ModalAddDB;
