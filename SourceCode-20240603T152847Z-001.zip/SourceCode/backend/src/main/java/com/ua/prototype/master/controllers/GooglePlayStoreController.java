package com.ua.prototype.master.controllers;

import com.ua.prototype.SeleniumTasksManager;
import com.ua.prototype.data.documents.User;
import com.ua.prototype.data.documents.tasks.SeleniumTask;
import com.ua.prototype.data.documents.tasks.SyncAppsTask;
import com.ua.prototype.master.managers.SeleniumClientsManager;
import com.ua.prototype.data.documents.GooglePlayStore;
import com.ua.prototype.data.repositories.ChromeStandaloneContainerRepository;
import com.ua.prototype.data.repositories.GooglePlayStoreRepository;
import com.ua.prototype.master.common.exceptions.BusinessException;
import com.ua.prototype.data.dto.ApiResponse;
import com.ua.prototype.data.dto.request.CreateGooglePlayStoreRequest;
import com.ua.prototype.data.dto.request.UpdateGooglePlayStoreRequest;
import com.ua.prototype.master.managers.SeleniumClient;
import com.ua.prototype.master.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;

/**
 * @author tuanlt
 */
@RestController
@RequestMapping("/api/v1/")
@RequiredArgsConstructor
public class GooglePlayStoreController {
    private final UserService userService;
    private final GooglePlayStoreRepository googlePlayStoreRepository;
    private final ChromeStandaloneContainerRepository chromeStandaloneContainerRepository;
    private final SeleniumTasksManager seleniumTasksManager;
    private final SeleniumClientsManager seleniumClientsManager;

    @GetMapping("google-play-stores")
    public ResponseEntity<?> getAllGooglePlayStores() {
        User user = userService.getCurrentUser();
        if (user.getRole().equalsIgnoreCase("admin")) {
            return ResponseEntity.ok(new ApiResponse(200, "Success", googlePlayStoreRepository.findAll()));
        } else {
            return ResponseEntity.ok(new ApiResponse(200, "Success",
                Collections.singleton(googlePlayStoreRepository.findById(user.getStoreId()).orElse(null))));
        }
    }

    @GetMapping("google-play-stores/{id}")
    public ResponseEntity<?> getGooglePlayStoreById(@PathVariable String id) {
        GooglePlayStore store = googlePlayStoreRepository.findById(id).orElse(null);
        if (store == null) {
            return ResponseEntity.ok(new ApiResponse(404, "Not found"));
        }
        return ResponseEntity.ok(new ApiResponse(200, "Success", store));
    }

    @PostMapping("google-play-stores")
    public ResponseEntity<?> createGooglePlayStore(@RequestBody CreateGooglePlayStoreRequest request) {
        GooglePlayStore store = new GooglePlayStore();
        store.setId(request.getId().trim());
        store.setName(request.getName().trim());
        store.setEmail(request.getEmail().trim());
        store.setCreatedAt(System.currentTimeMillis());
        googlePlayStoreRepository.save(store);
        return ResponseEntity.ok(new ApiResponse(201, "The developer account was created successfully!", store));
    }

    @PutMapping("google-play-stores/{id}")
    public ResponseEntity<?> updateGooglePlayStore(
        @PathVariable String id, @RequestBody UpdateGooglePlayStoreRequest request) {

        User user = userService.getCurrentUser();
        if (!user.getRole().equalsIgnoreCase("admin")) {
            throw new BusinessException(HttpStatus.FORBIDDEN, "You don't have permission");
        }

        GooglePlayStore store = googlePlayStoreRepository.findById(id).orElseThrow(
            () -> new BusinessException(HttpStatus.BAD_REQUEST, String.format("Store with id %s is not exists", id))
        );
        store.setName(request.getName());
        store.setEmail(request.getEmail());
        BeanUtils.copyProperties(request, store, "id");
        return ResponseEntity.ok(new ApiResponse(200, "The developer account was updated successfully!", googlePlayStoreRepository.save(store)));
    }

    @DeleteMapping("google-play-stores/{id}")
    public ResponseEntity<?> deleteGooglePlayStore(@PathVariable String id) {
        User user = userService.getCurrentUser();
        if (!user.getRole().equalsIgnoreCase("admin")) {
            throw new BusinessException(HttpStatus.FORBIDDEN, "You don't have permission");
        }

        if (!googlePlayStoreRepository.existsById(id)) {
            return ResponseEntity.ok(new ApiResponse(404, "Not found"));
        }
        googlePlayStoreRepository.deleteById(id);
        return ResponseEntity.ok(new ApiResponse(200, "The developer account was deleted successfully!"));
    }

    @PostMapping("google-play-stores/{id}/sync-apps")
    public ResponseEntity<?> syncApps(@PathVariable String id) {

        if (!googlePlayStoreRepository.existsById(id)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, String.format("Store with id %s is not exists", id));
        }

        SeleniumClient client = seleniumClientsManager.getClient(id);
        if (client == null) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, String.format("Cannot find an automated client for store with id %s", id));
        }

        SeleniumTask syncAppsTask = new SyncAppsTask();
        syncAppsTask.setDeveloperId(id);
        seleniumTasksManager.registerTask(syncAppsTask);

        return ResponseEntity.ok().body(new ApiResponse(200, "Your sync apps request has been sent! Please wait for a few minutes for it to be processed."));

    }

}
