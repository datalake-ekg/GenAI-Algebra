import React, { useState } from "react";
import PropTypes from "prop-types";
import Table from "antd/lib/table";
import Tooltip from "antd/lib/tooltip";
import { AiFillEye } from "@react-icons/all-files/ai/AiFillEye";
import DeleteOutlined from "@ant-design/icons/lib/icons/DeleteOutlined";
import { Link } from "react-router-dom";

function DatabaseTable(props) {
  const defaultPageSize = 10;
  const [pageSize, setPageSize] = useState(defaultPageSize);
  const { listData, onDelete, isLoading } = props;
  const onOpenDetail = (value) => {};

  const columns = [
    {
      title: "Name",
      render: (record) => (
        <div className="font-semibold text-black text-base">{record?.name}</div>
      ),
    },
    {
      title: "Number of record",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record?.no_of_record}
        </div>
      ),
    },
    {
      title: "Number of field",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record?.no_of_field}
        </div>
      ),
    },
    {
      title: "Action",
      width: 140,
      render: (text, record) => {
        return (
          <div className="flex space-x-2 ml-2">
            <>
              <Tooltip title="Open">
                <Link to="/database/detail">
                  <AiFillEye
                    size={20}
                    className="text-slate-600 hover:text-antPrimary cursor-pointer"
                    onClick={() => {
                      onOpenDetail(record);
                    }}
                  />
                </Link>
              </Tooltip>

              <Tooltip title="Delete Database">
                <DeleteOutlined
                  size={20}
                  className="icon-danger text-xl cursor-pointer"
                  onClick={() => onDelete(record)}
                />
              </Tooltip>
            </>
          </div>
        );
      },
    },
  ];

  const pagination = {
    hideOnSinglePage: true,
    pageSize,
    showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
  };

  return (
    <Table
      id="custom-store-listing-table"
      rowKey={(record) => record.id}
      columns={columns}
      loading={isLoading}
      dataSource={[...listData]}
      scroll={{ x: 600 }}
      size="middle"
      pagination={pagination}
      onChange={(pagination) => {
        pagination?.pageSize && setPageSize(pagination?.pageSize);
      }}
    />
  );
}

DatabaseTable.defaultProps = {
  listData: [],
};
DatabaseTable.propTypes = {
  onDelete: PropTypes.func,
  isLoading: PropTypes.bool,
  listData: PropTypes.array,
};

export default DatabaseTable;
