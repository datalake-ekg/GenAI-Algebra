import React, { useState, useEffect } from "react";
import Page from "../../utils/composables/Page";
import Loading from "../../utils/Loading";
import DatabaseTable from "./DatabaseTable";
import AntInput from "antd/lib/input/Input";
import SearchOutlined from "@ant-design/icons/lib/icons/SearchOutlined";
import Button from "antd/lib/button/button";

import service from "../../partials/services/axios.config";
import { Select } from "antd";
import { toast } from "react-toastify";
import ModalAddDB from "./ModalAddDB";
function Database() {
  const [isLoading, setIsLoading] = useState(false);
  const [listDB, setListDB] = useState<any>([]);
  const [search, setSearch] = useState("");
  const [isOpenModalAdd, setIsOpenModalAdd] = useState(false);
  const onDelete = () => {};

  const onSearch = (value) => {};

  useEffect(() => {
    setIsLoading(true);
    service.get("/database").then(
      (res: any) => {
        setListDB(res.results);
        setIsLoading(false);
      },
      () => setIsLoading(false)
    );
  }, []);

  return (
    <Page>
      {isLoading && <Loading />}
      <div>
        <div>
          <div className="flex justify-between">
            <div className="page-title">Database</div>
          </div>
          <div
            className="bg-white p-4 rounded-sm shadow mt-2"
            style={{ marginBottom: 20 }}
          >
            <div className="flex items-center flex-wrap -mx-1 2xl:-mx-2 -mt-3">
              <AntInput
                allowClear
                placeholder="Search name"
                className="xs:!w-[200px] mx-1 2xl:!mx-2 mt-3"
                prefix={<SearchOutlined />}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <Button
                type="primary"
                className="mx-1 2xl:!mx-2 mt-3"
                style={{ marginLeft: "60%" }}
                onClick={() => setIsOpenModalAdd(true)}
              >
                Import Database
              </Button>
            </div>
          </div>
          <DatabaseTable onDelete={onDelete} listData={listDB} />
        </div>
        <ModalAddDB
          isOpen={isOpenModalAdd}
          onClose={() => setIsOpenModalAdd(false)}
          setIsLoading={setIsLoading}
          setListDB={setListDB}
        />
      </div>
    </Page>
  );
}

export default Database;
