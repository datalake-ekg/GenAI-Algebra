import React, { useState, useEffect } from "react";
import Page from "../../utils/composables/Page";
import Loading from "../../utils/Loading";
import DatabaseDetailTable from "./DatabaseDetailTable";
import AntInput from "antd/lib/input/Input";
import SearchOutlined from "@ant-design/icons/lib/icons/SearchOutlined";
import Button from "antd/lib/button/button";
import { Select } from "antd";
import service from "../../partials/services/axios.config";
import ModalAdd from "./ModalAdd";
import LSTable from "./LSTable";
function DatabaseDetail() {
  const [isLoading, setIsLoading] = useState(false);
  const [listRecord, setListRecord] = useState<any>([]);
  const [listLS, setListLS] = useState<any>([]);
  const [isOpenModalAdd, setIsOpenModalAdd] = useState(false);
  const onDelete = () => {};

  const onSearch = (value) => {};
  useEffect(() => {
    setIsLoading(true);
    service.get("/record").then(
      (res: any) => {
        setListRecord(res.results);
        setIsLoading(false);
      },
      () => setIsLoading(false)
    );
  }, []);

  return (
    <Page>
      {isLoading && <Loading />}
      <div>
        <div>
          <div className="flex justify-between">
            <div className="page-title">Records</div>
          </div>

          <DatabaseDetailTable onDelete={onDelete} listData={listRecord} />
          <div
            className="bg-white p-4 rounded-sm shadow mt-2"
            style={{ marginBottom: 20 }}
          >
            <div style={{ fontSize: 20, fontWeight: "bold", marginBottom: 20 }}>
              Default quantifier semantic core
            </div>
            <div className="flex items-center flex-wrap -mx-1 2xl:-mx-2 -mt-3">
              <div style={{ marginLeft: 10, marginRight: 5 }}>None:</div>
              <AntInput
                className="xs:!w-[100px] mx-1 2xl:!mx-2 mt-3"
                value={"0 - 0.1"}
              />
              <div style={{ marginLeft: 10, marginRight: 5 }}>Few:</div>
              <AntInput
                className="xs:!w-[100px] mx-1 2xl:!mx-2 mt-3"
                value={"0.2 - 0.3"}
              />
              <div style={{ marginLeft: 10, marginRight: 5 }}>A half:</div>
              <AntInput
                className="xs:!w-[100px] mx-1 2xl:!mx-2 mt-3"
                value={"0.4 - 0.6"}
              />
              <div style={{ marginLeft: 10, marginRight: 5 }}>Many:</div>
              <AntInput
                className="xs:!w-[100px] mx-1 2xl:!mx-2 mt-3"
                value={"0.7 - 0.8"}
              />
              <div style={{ marginLeft: 10, marginRight: 5 }}>Almost:</div>
              <AntInput
                className="xs:!w-[100px] mx-1 2xl:!mx-2 mt-3"
                value={"0.9 - 1"}
              />
            </div>
          </div>
          <div
            className="bg-white p-4 rounded-sm shadow mt-2"
            style={{ marginBottom: 20 }}
          >
            <Button onClick={() => setIsOpenModalAdd(true)}>
              Generate Linguistic Summary
            </Button>
          </div>
          <LSTable
          listData={listLS}
          />
        </div>
      </div>
      <ModalAdd
        isOpen={isOpenModalAdd}
        onClose={() => setIsOpenModalAdd(false)}
        setIsLoading={setIsLoading}
        setListLS = {setListLS}
      />
    </Page>
  );
}

export default DatabaseDetail;
