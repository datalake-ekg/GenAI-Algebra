package com.ua.prototype;

import com.ua.prototype.master.common.AppUtils;
import com.ua.prototype.master.common.utils.FileUtils;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author tuanlt. Backend server and selenium servers should be in the same virtual machine, so that they can use the same local disk space.
 */
@UtilityClass
public class FileSharingUtils {
    static final String ROOT_DIRECTORY = AppUtils.getPath(AppUtils.WORKING_DIRECTORY, "shared_directory");

    public String saveFile(String developerId, MultipartFile multipartFile) {
        return FileUtils.saveMultipartFileToDisk(AppUtils.getPath(ROOT_DIRECTORY, AppUtils.getPathForYYMMDD(), developerId), multipartFile);
//        assert absolutePath != null;
//        return absolutePath.replace(ROOT_DIRECTORY, "");
    }

}
