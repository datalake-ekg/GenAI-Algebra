package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.Database;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface DatabseService {
    List<Database> findAll();

    boolean processFile (MultipartFile file, String name);
}
