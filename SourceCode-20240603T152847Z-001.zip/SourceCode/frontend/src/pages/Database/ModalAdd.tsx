import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import Button from "antd/lib/button";
import Modal from "antd/lib/modal/Modal";
import Form from "antd/lib/form";
import AntInput from "antd/lib/input";
import { Select } from "antd";
import { toast } from "react-toastify";
import service from "../../partials/services/axios.config";
function ModalAdd(props) {
  const [form] = Form.useForm();
  const { isOpen, onClose, setIsLoading, setListLS } = props;

  const onCloseModal = () => {
    onClose();
    setTimeout(() => {
      form.resetFields();
    }, 300);
  };

  const onGenerate = (values) => {
    console.log(values)
    setIsLoading(true);
    service.post("/ls", values).then(
      (res: any) => {
        console.log(res.results);
        setListLS(res.results);
        setIsLoading(false);
        onCloseModal();
      },
      () => setIsLoading(false)
    );
  };

  return (
    <Form
      id="FormAdd"
      labelAlign="left"
      form={form}
      labelCol={{ span: 24 }}
      wrapperCol={{ span: 24 }}
      onFinish={onGenerate}
    >
      <Modal
        title="Generate Linguistic Summary"
        open={isOpen}
        onCancel={onCloseModal}
        footer={[
          <Button key="back" htmlType="button" onClick={onCloseModal}>
            Cancel
          </Button>,
          <Button key="submit" type="primary" htmlType="submit" form="FormAdd">
            Generate
          </Button>,
        ]}
      >
        <Form.Item
          name="feature"
          label="Select feature"
          rules={[{ required: true, message: "Please choose feature" }]}
        >
          <Select
            allowClear
            placeholder="Select feature"
            className="w-full"
            onChange={(selectedOptions) => {
              form.setFieldsValue({ selectFeature: selectedOptions });
            }}
          >
            <Select.Option value="age">Age </Select.Option>
            <Select.Option value="resting_blood_pressure">
              Resting blood pressure
            </Select.Option>
            <Select.Option value="serum_cholesterol">
              Serum cholesterol
            </Select.Option>
            <Select.Option value="maximum_heart_rate_archived">
              Maximum heart rate archived
            </Select.Option>
          </Select>
        </Form.Item>
        <div className="flex items-center flex-wrap -mx-1 2xl:-mx-2 -mt-3">
          <div style={{ width: "40%", marginLeft: "5%", marginRight: "5%" }}>
            <Form.Item
              name="c_negative"
              label="Element c-"
              rules={[{ required: true, message: "Please enter value" }]}
            >
              <AntInput allowClear placeholder="Enter" className="w-full" />
            </Form.Item>
          </div>
          <div style={{ width: "40%", marginLeft: "5%", marginRight: "5%" }}>
            <Form.Item
              name="c_positive"
              label="Element c+"
              rules={[{ required: true, message: "Please enter value" }]}
            >
              <AntInput allowClear placeholder="Enter" className="w-full" />
            </Form.Item>
          </div>
        </div>
        <Form.Item
          name="fuzzyRange0"
          label="Fuzzy range `0`"
          rules={[{ required: true, message: "Please enter value" }]}
        >
          <AntInput allowClear placeholder="Enter" className="w-full" />
        </Form.Item>
        <Form.Item
          name="fuzzyRangeW"
          label="Fuzzy range `W`"
          rules={[{ required: true, message: "Please enter value" }]}
        >
          <AntInput allowClear placeholder="Enter" className="w-full" />
        </Form.Item>
        <Form.Item
          name="fuzzyRange1"
          label="Fuzzy range `1`"
          rules={[{ required: true, message: "Please enter value" }]}
        >
          <AntInput allowClear placeholder="Enter" className="w-full" />
        </Form.Item>
        <div className="flex items-center flex-wrap -mx-1 2xl:-mx-2 -mt-3">
          <div style={{ width: "40%", marginLeft: "5%", marginRight: "5%" }}>
            <Form.Item
              name="h0"
              label="Measure of fuzziness h0"
              rules={[{ required: true, message: "Please enter value" }]}
            >
              <AntInput allowClear placeholder="Enter" className="w-full" />
            </Form.Item>
          </div>
          <div style={{ width: "40%", marginLeft: "5%", marginRight: "5%" }}>
            <Form.Item
              name="m"
              label="Separate rate m"
              rules={[{ required: true, message: "Please enter value" }]}
            >
              <AntInput allowClear placeholder="Enter" className="w-full" />
            </Form.Item>
          </div>
        </div>
        <Form.Item
          name="filter"
          label="
              Filteration condition"
        >
          <Select
            allowClear
            placeholder="Select filter"
            className="w-full"
            onChange={(selectedOptions) => {
              form.setFieldsValue({ filter: selectedOptions });
            }}
          >
            <Select.Option value="filter">target = 1</Select.Option>
          </Select>
        </Form.Item>
      </Modal>
    </Form>
  );
}

ModalAdd.propTypes = {
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
  setListLS: PropTypes.func,
  setIsLoading: PropTypes.func,
};

export default ModalAdd;
