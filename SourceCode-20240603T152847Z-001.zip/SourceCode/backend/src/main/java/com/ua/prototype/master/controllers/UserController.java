package com.ua.prototype.master.controllers;

import com.ua.prototype.data.documents.GooglePlayStore;
import com.ua.prototype.data.documents.User;
import com.ua.prototype.data.dto.*;
import com.ua.prototype.data.repositories.GooglePlayStoreRepository;
import com.ua.prototype.master.common.obj.CreateNewPasswordPayload;
import com.ua.prototype.master.services.GooglePlayStoreService;
import com.ua.prototype.master.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import javax.mail.MessagingException;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class UserController {
    private final UserService userService;
    private final GooglePlayStoreRepository googlePlayStoreRepository;
    @PostMapping("/user/create-new-password")
    public ResponseEntity<ApiResponse> createNewPassword(@RequestBody CreateNewPasswordPayload payload) {
        userService.createNewPassword(payload.getToken(), payload.getPassword());
        return ResponseEntity.ok(new ApiResponse(200, "Đặt lại mật khẩu thành công!"));
    }

    @PostMapping("/user/reset-password")
    public ResponseEntity<ApiResponse> resetPassword(@RequestBody ResetPasswordRequest request) throws MessagingException {
        userService.sendResetPasswordEmail(request.getEmail());
        return ResponseEntity.ok(new ApiResponse(200, "Please check your email and follow the instructions to reset your password."));
    }

    @PostMapping("/user/changePassword")
    public ResponseEntity<ApiResponse> changePassword(@RequestBody ChangePasswordRequest request) {
        userService.changePassword(request);
        return ResponseEntity.ok(new ApiResponse(200, "change password success"));
    }

    @GetMapping("/user")
    public ResponseEntity<ApiResponse> getCurrentUser() {
        return ResponseEntity.ok(new ApiResponse(200, "Get current user success", userService.getCurrentUser()));
    }


    @GetMapping("/user/findAll")
    public ResponseEntity<ApiResponse> getAllUser() {
        List <User> listUser = userService.findAll();
        for (User user: listUser
             ) {
            GooglePlayStore store = googlePlayStoreRepository.findGooglePlayStoreById(user.getStoreId());
            if(store == null) continue;
            user.setStoreName(store.getName());
        }
        return ResponseEntity.ok(new ApiResponse(200, "Get all user success", listUser));
    }

    @PostMapping("/user/updateUser")
    public ResponseEntity<ApiResponse> updateUser(@RequestBody UserDTO request) {
        userService.update(request);
        return ResponseEntity.ok(new ApiResponse(200, "update user success"));
    }

    @PostMapping("/user/updateUserRole")
    public ResponseEntity<ApiResponse> updateUser(@RequestBody User request) {
        userService.updateUserRole(request);
        return ResponseEntity.ok(new ApiResponse(200, "update user role success"));
    }

    @PostMapping("/user/activeUser")
    public ResponseEntity<ApiResponse> activeUser(@RequestBody ChangeActiveStatusRequest request) {
        userService.activeUser(request.getId());
        return ResponseEntity.ok(new ApiResponse(200, "active user success"));
    }

    @PostMapping("/user/deactiveUser")
    public ResponseEntity<ApiResponse> deactiveUser(@RequestBody ChangeActiveStatusRequest request) {
        userService.deactivate(request.getId());
        return ResponseEntity.ok(new ApiResponse(200, "deactivate user success"));
    }
}
