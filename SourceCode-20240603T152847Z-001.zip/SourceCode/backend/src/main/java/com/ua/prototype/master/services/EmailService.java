package com.ua.prototype.master.services;

public interface EmailService {
    public void addToQueue(String to, String subject, String body) ;
}
