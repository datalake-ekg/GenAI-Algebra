package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.NetworkConnector;
import com.ua.prototype.data.documents.Theme;
import com.ua.prototype.data.dto.AppsflyerMetricResponse;

import java.util.Date;
import java.util.List;

/**
 * @author thanhnd
 */
public interface FetchDataService {
    void fetchNetworkReport(NetworkConnector networkConnector, Date startDate, Date endDate);

    List<AppsflyerMetricResponse> fetchAppsflyerReport(Theme theme, NetworkConnector appsflyerConnector, Date crawDate);

}
