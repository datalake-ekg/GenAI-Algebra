import React, { useState } from "react";
import PropTypes from "prop-types";
import Table from "antd/lib/table";

import Tooltip from "antd/lib/tooltip";
import { AiFillEye } from "@react-icons/all-files/ai/AiFillEye";
import DeleteOutlined from "@ant-design/icons/lib/icons/DeleteOutlined";
import { Link } from "react-router-dom";

function DatabaseDetailTable(props) {
  const defaultPageSize = 10;
  const [pageSize, setPageSize] = useState(defaultPageSize);
  const { listData, isLoading } = props;

  const columns = [
    {
      title: "Age",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.age}
        </div>
      ),
    },
    {
      title: "Gender",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.sex == 1 ? "Female" : "Male"}
        </div>
      ),
    },
    {
      title: "Chest pain type",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.chest_pain_type}
        </div>
      ),
    },
    {
      title: "Resting blood pressure",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.resting_blood_pressure}
        </div>
      ),
    },
    {
      title: "Serum cholesterol",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.serum_cholesterol}
        </div>
      ),
    },
    {
      title: "Fasting blood sugar over 120mg per dl",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.fasting_blood_sugar_over_120mg_per_dl}
        </div>
      ),
    },
    {
      title: "Resting electrocardiogram results",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.resting_electrocardiogram_results}
        </div>
      ),
    },
    {
      title: "Maximum heart rate achived",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.maximum_heart_rate_achieved}
        </div>
      ),
    },
    {
      title: "Exercise induced angina",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.exercise_induced_angina}
        </div>
      ),
    },
    {
      title: "Oldpeak",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.oldpeak}
        </div>
      ),
    },
    {
      title: "Slope",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.slope}
        </div>
      ),
    },
    {
      title: "CA",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.ca}
        </div>
      ),
    },
    {
      title: "Thal",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.thal}
        </div>
      ),
    },
    {
      title: "target",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record.target == 0 ? "False" : "True"}
        </div>
      ),
    },
  ];

  const pagination = {
    hideOnSinglePage: true,
    pageSize,
    showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
  };

  return (
    <Table
      id="custom-store-listing-table"
      rowKey={(record) => record.id}
      columns={columns}
      loading={isLoading}
      dataSource={[...listData]}
      scroll={{ x: 2000 }}
      size="middle"
      pagination={pagination}
      onChange={(pagination) => {
        pagination?.pageSize && setPageSize(pagination?.pageSize);
      }}
    />
  );
}

DatabaseDetailTable.defaultProps = {
  listData: [],
};
DatabaseDetailTable.propTypes = {
  onDelete: PropTypes.func,
  isLoading: PropTypes.bool,
  listData: PropTypes.array,
};

export default DatabaseDetailTable;
