package com.ua.prototype.master.managers;

import com.ua.prototype.master.managers.SeleniumClient;
import com.ua.prototype.master.websocket.WebSocketEventListener;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author tuanlt
 */
@Component
@RequiredArgsConstructor
public class SeleniumClientsManager {

    private final SimpMessagingTemplate socketTemplate;
    private final Map<String, SeleniumClient> clients = new ConcurrentHashMap<>();
    private final AtomicBoolean shouldUpdate = new AtomicBoolean(false);

    public void markShouldUpdateToBeTrue() {
        shouldUpdate.set(true);
    }

    public SeleniumClient getClient(String developerId) {
        return clients.get(developerId);
    }

    @Scheduled(fixedRate = 5_000L)
    private void update() {
        if (shouldUpdate.compareAndSet(true, false)) {
            socketTemplate.convertAndSend("/topic/selenium-clients", Collections.singletonMap("clients", clients.values()));
        }
    }

    public void updateInfo(SeleniumClient client) {
        client.setLastPing(System.currentTimeMillis());
        SeleniumClient currentClient = clients.get(client.getId());
        if (currentClient == null) {
            clients.put(client.getId(), client);
            shouldUpdate.set(true);
            return;
        }
        currentClient.setLastPing(System.currentTimeMillis());
        if (currentClient.getType() != null && currentClient.getType() != client.getType()) {
            currentClient.setType(client.getType());
            shouldUpdate.set(true);
        } else if (client.getType() != null && client.getType() != currentClient.getType()) {
            currentClient.setType(client.getType());
            shouldUpdate.set(true);
        }
        if (currentClient.getState() != null && currentClient.getState() != client.getState()) {
            currentClient.setState(client.getState());
            shouldUpdate.set(true);
        } else if (client.getState() != null && client.getState() != currentClient.getState()) {
            currentClient.setState(client.getState());
            shouldUpdate.set(true);
        }

    }
}
