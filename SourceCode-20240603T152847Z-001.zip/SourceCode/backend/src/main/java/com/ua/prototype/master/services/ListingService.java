package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.MainListing;
import com.ua.prototype.data.documents.tasks.FetchCustomListingsTask;
import com.ua.prototype.data.documents.tasks.GetMainListingTask;
import com.ua.prototype.data.objects.CustomListing;

import java.util.List;

public interface ListingService {
    List<CustomListing> getAllCustomListings(String consoleAppId);

    MainListing getMainListing(String appId);

    GetMainListingTask getMainListingLastSync(String appId);

    FetchCustomListingsTask getCustomListingsLastSync(String appId);

    CustomListing findById(String id);
}
