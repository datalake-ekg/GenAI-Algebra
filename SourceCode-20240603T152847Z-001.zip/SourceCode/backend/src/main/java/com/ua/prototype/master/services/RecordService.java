package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.Record;

import java.util.List;

public interface RecordService {
    List<Record> findAll();

    List<Record> findAllByTarget(int target);
}
