//package com.ua.prototype.master.managers;
//
//import com.google.common.cache.Cache;
//import com.google.common.cache.CacheBuilder;
//import com.google.common.cache.CacheLoader;
//import com.google.common.cache.LoadingCache;
//import com.ua.prototype.data.documents.GooglePlayStore;
//import lombok.Data;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.RandomUtils;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.messaging.simp.SimpMessagingTemplate;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import javax.annotation.PostConstruct;
//import java.util.*;
//import java.util.concurrent.TimeUnit;
//
//@Slf4j
//@Service
//@RequiredArgsConstructor
//public class GoogleStoresManager {
//
//    static final String TOPIC = "/topic/google-play-stores";
//
//    private final MongoTemplate mongoTemplate;
//    private final SimpMessagingTemplate socketTemplate;
//
//    private final LoadingCache<String, GooglePlayStore> cache = CacheBuilder.newBuilder()
//            .maximumSize(100)
//            .expireAfterAccess(10, TimeUnit.MINUTES)
//            .build(new CacheLoader<String, GooglePlayStore>() {
//                @Override
//                public GooglePlayStore load(String key) throws Exception {
//                    return mongoTemplate.findById(key, GooglePlayStore.class);
//                }
//            });
//
//    @PostConstruct
//    private void init() {
//        try {
//            List<GooglePlayStore> stores = mongoTemplate.findAll(GooglePlayStore.class);
//            for (GooglePlayStore store : stores) {
//                cache.put(store.getId(), store);
//            }
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//    }
//
//    public Collection<GooglePlayStore> getAll() {
//        return cache.asMap().values();
//    }
//
//    public GooglePlayStore get(String id) {
//
//        try {
//            return cache.get(id);
//        } catch (Exception e) {
//            return null;
//        }
//
//    }
//
//    public void delete(GooglePlayStore store) {
//        try {
//            mongoTemplate.remove(store);
//            cache.invalidate(store.getId());
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//
//    }
//
//    public GooglePlayStore save(GooglePlayStore store) {
//        try {
//            store = mongoTemplate.save(store);
//            updateCache(store);
//            return store;
//        } catch (Exception e) {
//            return null;
//        }
//    }
//
//    private void updateCache(GooglePlayStore store) {
//        cache.put(store.getId(), store);
//        socketTemplate.convertAndSend(TOPIC, store);
//    }
//
//
////    @Scheduled(fixedDelay = 10_000)
////    private void fake() {
////        cache.asMap().values().forEach(store -> {
////            store.setSyncingApps(RandomUtils.nextBoolean());
////            socketTemplate.convertAndSend(TOPIC, store);
////        });
////    }
//
//
//}
