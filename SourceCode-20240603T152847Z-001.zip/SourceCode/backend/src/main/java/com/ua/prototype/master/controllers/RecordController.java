package com.ua.prototype.master.controllers;

import com.ua.prototype.data.dto.ApiResponse;
import com.ua.prototype.master.services.DatabseService;
import com.ua.prototype.master.services.RecordService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class RecordController {
    private final RecordService recordService;
    @GetMapping("/record")
    public ResponseEntity<ApiResponse> findAll() {
        return ResponseEntity.ok(new ApiResponse(200, "Get all record success", recordService.findAll()));
    }
}
