package com.ua.prototype.master.controllers;

import com.ua.prototype.data.dto.ApiResponse;
import com.ua.prototype.master.services.AppService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * @author thanhnd
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class AppController {

    private final AppService appService;

    @GetMapping("/apps")
    public ResponseEntity<ApiResponse> getAll() {
        return ResponseEntity.ok(new ApiResponse(200, "Get all app success", appService.getAll()));
    }

    @GetMapping("/app")
    public ResponseEntity<ApiResponse> getById(@RequestParam(value = "id") String appId,
                                               @RequestParam(value = "startDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                               @RequestParam(value = "endDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
        return ResponseEntity.ok(new ApiResponse(200, "Get all app success", appService.getById(appId, startDate, endDate)));
    }

}
