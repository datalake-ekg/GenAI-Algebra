package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.App;

import java.util.Date;
import java.util.List;

/**
 * @author thanhnd
 */
public interface AppService {
    List<App> getAll();

    App getById(String id, Date startDate, Date endDate);
}
