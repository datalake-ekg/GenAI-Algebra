import React, { useState } from "react";
import PropTypes from "prop-types";
import Table from "antd/lib/table";
import Tooltip from "antd/lib/tooltip";
import { AiFillEye } from "@react-icons/all-files/ai/AiFillEye";
import DeleteOutlined from "@ant-design/icons/lib/icons/DeleteOutlined";
import { Link } from "react-router-dom";

function LSTable(props) {
  const defaultPageSize = 10;
  const [pageSize, setPageSize] = useState(defaultPageSize);
  const { listData, isLoading } = props;

  const columns = [
    {
      title: "Content",
      render: (record) => (
        <div className="font-semibold text-black text-base">{record?.Q + "-people has heart diease have-" + record?.Feature + "-is-" + record?.S}</div>
      ),
    },
    {
      title: "Truth value",
      render: (record) => (
        <div className="whitespace-nowrap md:whitespace-normal">
          {record?.T}
        </div>
      ),
    },
  ];

  const pagination = {
    hideOnSinglePage: true,
    pageSize,
    showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
  };

  return (
    <Table
      id="custom-store-listing-table"
      rowKey={(record) => record.id}
      columns={columns}
      loading={isLoading}
      dataSource={[...listData]}
      scroll={{ x: 600 }}
      size="middle"
      pagination={pagination}
      onChange={(pagination) => {
        pagination?.pageSize && setPageSize(pagination?.pageSize);
      }}
    />
  );
}

LSTable.defaultProps = {
  listData: [],
};
LSTable.propTypes = {
  isLoading: PropTypes.bool,
  listData: PropTypes.array,
};

export default LSTable;
