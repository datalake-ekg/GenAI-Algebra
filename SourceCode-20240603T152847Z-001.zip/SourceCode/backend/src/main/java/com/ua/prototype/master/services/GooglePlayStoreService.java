package com.ua.prototype.master.services;

public interface GooglePlayStoreService {

}
