package com.ua.prototype;

import com.ua.prototype.data.repositories.tasks.SeleniumTasksRepository;
import com.ua.prototype.data.documents.tasks.SeleniumTask;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author tuanlt
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SeleniumTasksManager {

    private final SeleniumTasksRepository seleniumTasksRepository;
    private final Map<String, ConcurrentLinkedQueue<SeleniumTask>> tasksByDeveloperId = new ConcurrentHashMap<>();

    @PostConstruct
    private void init() {
        try {
            seleniumTasksRepository.findByState(SeleniumTask.State.CREATED).forEach(this::registerTask);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void registerTask(SeleniumTask task) {
        seleniumTasksRepository.save(task);
        tasksByDeveloperId.computeIfAbsent(task.getDeveloperId(), k -> new ConcurrentLinkedQueue<>()).add(task);
    }

    public SeleniumTask getTasksByDeveloperId(String developerId) {
        return tasksByDeveloperId.computeIfAbsent(developerId, k -> new ConcurrentLinkedQueue<>()).poll();
    }

}
