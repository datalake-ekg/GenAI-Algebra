package com.ua.prototype.master.managers;

import com.ua.prototype.data.documents.tasks.SeleniumTask;
import lombok.Data;

/**
 * @author tuanlt
 */
@Data
public class SeleniumClient {

    private String id;
    private String name;
    private String vncUrl;
    private State state;
    private Type type;
    private long lastPing = 0L;
    private String appId;


    public enum State {
        LOGIN_REQUIRE,
        IDLE,
        PROCESSING,

        SYNCING_APPS,

    }

    public enum Type {
        CREATE_RELEASE,
        EDIT_MAIN_LISTING,
        GET_MAIN_LISTING,
        FETCH_CUSTOM_LISTINGS,
        CHECK_LOGIN_STATUS,
        CREATE_CUSTOM_LISTING,
        SYNC_APPS,
    }
}
