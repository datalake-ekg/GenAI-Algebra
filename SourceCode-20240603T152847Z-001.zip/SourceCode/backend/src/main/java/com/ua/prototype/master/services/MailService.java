package com.ua.prototype.master.services;

import javax.mail.MessagingException;

/**
 * @author thanhnd
 */
public interface MailService {
    void sendAccountInfoToUser(String email, String password) throws MessagingException;

    void sendResetPasswordToUser(String email, String password) throws MessagingException;
}
