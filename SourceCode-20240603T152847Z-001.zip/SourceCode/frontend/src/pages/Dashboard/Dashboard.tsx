import React from "react";
import Page from "../../utils/composables/Page";

function Dashboard() {
  return (
    <Page>
      <div>Dashboard</div>
    </Page>
  );
}

export default Dashboard;
