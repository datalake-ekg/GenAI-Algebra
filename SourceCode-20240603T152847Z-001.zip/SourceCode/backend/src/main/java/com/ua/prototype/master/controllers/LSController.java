package com.ua.prototype.master.controllers;

import com.ua.prototype.data.documents.Feature;
import com.ua.prototype.data.dto.ApiResponse;
import com.ua.prototype.master.services.LSService;
import com.ua.prototype.master.services.RecordService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class LSController {
    private final LSService lsService;
    @PostMapping("/ls")
    public ResponseEntity<ApiResponse> generate(@RequestBody Feature request) {
        return ResponseEntity.ok(new ApiResponse(200, "generate success", lsService.generateLS(request)));
    }
}
