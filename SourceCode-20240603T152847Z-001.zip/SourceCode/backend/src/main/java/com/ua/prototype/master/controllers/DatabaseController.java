package com.ua.prototype.master.controllers;

import com.ua.prototype.data.dto.ApiResponse;
import com.ua.prototype.data.dto.ImportDBRequest;
import com.ua.prototype.data.dto.ReleaseAppDTO;
import com.ua.prototype.master.services.DatabseService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class DatabaseController {
    private final DatabseService databseService;
    @GetMapping("/database")
    public ResponseEntity<ApiResponse> findAll() {
        return ResponseEntity.ok(new ApiResponse(200, "Get all database success", databseService.findAll()));
    }

    @PostMapping("/upload")
    public ResponseEntity<ApiResponse> uploadFile(@ModelAttribute ImportDBRequest request) {
        boolean success = databseService.processFile(request.getFile(), request.getName());
        return ResponseEntity.ok(new ApiResponse(200, "Upload file success"));
    }
}
