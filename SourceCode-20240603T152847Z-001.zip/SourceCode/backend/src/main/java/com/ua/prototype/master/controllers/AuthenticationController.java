package com.ua.prototype.master.controllers;

import com.ua.prototype.data.dto.ApiResponse;
import com.ua.prototype.data.dto.AuthenticationRequest;
import com.ua.prototype.master.services.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * @author thanhnd
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class AuthenticationController {

    private final AuthenticationService authenticationService;

    @PostMapping("/authenticate")
    public ResponseEntity<ApiResponse> authenticate(HttpServletRequest httpServletRequest, @RequestBody AuthenticationRequest request) {
        return ResponseEntity.ok(new ApiResponse(200, "Authenticate success", authenticationService.authenticate(request, httpServletRequest)));
    }


}
