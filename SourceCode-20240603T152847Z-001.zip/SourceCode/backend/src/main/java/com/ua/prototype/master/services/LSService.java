package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.Feature;

import java.util.List;
import java.util.Map;

public interface LSService {
    List<Map<String, Object>> generateLS (Feature feature);
}
