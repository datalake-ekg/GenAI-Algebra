import Vue from 'vue'
Vue.config.productionTip = false
export { default as Chat } from './components/Chat.vue';
