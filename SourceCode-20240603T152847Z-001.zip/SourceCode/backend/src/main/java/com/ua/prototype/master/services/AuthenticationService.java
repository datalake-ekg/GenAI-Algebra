package com.ua.prototype.master.services;

import com.ua.prototype.data.dto.AuthenticationRequest;

import javax.servlet.http.HttpServletRequest;

/**
 * @author thanhnd
 */
public interface AuthenticationService {

    /**
     * Generate token or Google Authenticator code
     * @param request request
     * @param httpServletRequest client request
     * @return Token or Google Authenticator code
     */
    String authenticate(AuthenticationRequest request, HttpServletRequest httpServletRequest);

}
