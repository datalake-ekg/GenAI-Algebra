package com.ua.prototype.master.services;


import com.ua.prototype.master.common.enums.MailType;

/**
 * @author tuanlt
 */
public interface MailTemplateService {
    void loadTemplate(MailType mailType, String fileName);

    String getTemplate(MailType mailType);
}
