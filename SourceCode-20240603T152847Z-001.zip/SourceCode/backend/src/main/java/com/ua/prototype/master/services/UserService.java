package com.ua.prototype.master.services;

import com.ua.prototype.data.documents.User;

import com.ua.prototype.data.dto.UserDTO;
import com.ua.prototype.data.dto.ChangePasswordRequest;
import org.springframework.security.core.userdetails.UserDetailsService;

import javax.mail.MessagingException;
import java.util.List;

/**
 * @author thanhnd
 */
public interface UserService extends UserDetailsService {


    void inviteUser(String email, String role, String storeId) throws MessagingException;

//    void resetPassword(String email) throws MessagingException;

    User changePassword(ChangePasswordRequest changePasswordRequest);

    List<User> findAll();

    List<User> findByStoreAppId(String storeAppId);

    User update(UserDTO userDTO);

    User updateUserRole(User user);

    User activeUser(String id);

    User deactivate(String id);

    void resendQRCode(String email);

    User getCurrentUser();

    void sendResetPasswordEmail(String email);

    void createNewPassword(String token, String password);
}
